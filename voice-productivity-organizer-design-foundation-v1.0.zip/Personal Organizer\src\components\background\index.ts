export { default as GradientBackground, useTimeBasedGradient } from './GradientBackground';
