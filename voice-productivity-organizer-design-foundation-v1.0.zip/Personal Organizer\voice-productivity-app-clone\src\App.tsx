import React, { useState } from 'react';

interface Item {
  id: string;
  type: 'calendar' | 'task' | 'note';
  title: string;
  description?: string;
  completed?: boolean;
  priority?: 'high' | 'medium' | 'low';
  dueDate?: string;
  startTime?: string;
  endTime?: string;
  location?: string;
  content?: string;
  tags?: string[];
}

function App() {
  const [items, setItems] = useState<Item[]>([
    {
      id: '1',
      type: 'calendar',
      title: 'Team Meeting',
      description: 'Weekly team sync',
      startTime: '10:00 AM',
      endTime: '11:00 AM',
      location: 'Conference Room A'
    },
    {
      id: '2',
      type: 'task',
      title: 'Review quarterly reports',
      description: 'Q4 financial review',
      priority: 'high',
      dueDate: 'Today',
      completed: false
    },
    {
      id: '3',
      type: 'note',
      title: 'Project Ideas',
      content: 'Brainstorming session notes for new features...',
      tags: ['work', 'planning', 'ideas']
    }
  ]);

  const [activeForm, setActiveForm] = useState<'calendar' | 'task' | 'note' | null>(null);
  const [showVoiceModal, setShowVoiceModal] = useState(false);
  const [voiceInput, setVoiceInput] = useState('');
  const [isListening, setIsListening] = useState(false);

  const [newItem, setNewItem] = useState({
    title: '',
    description: '',
    priority: 'medium' as 'high' | 'medium' | 'low',
    dueDate: '',
    startTime: '',
    endTime: '',
    location: '',
    content: '',
    tags: ''
  });

  const handleCreateItem = () => {
    if (!newItem.title.trim() || !activeForm) return;

    const item: Item = {
      id: Date.now().toString(),
      type: activeForm,
      title: newItem.title,
      description: newItem.description || undefined,
      ...(activeForm === 'task' && {
        priority: newItem.priority,
        dueDate: newItem.dueDate || undefined,
        completed: false
      }),
      ...(activeForm === 'calendar' && {
        startTime: newItem.startTime || undefined,
        endTime: newItem.endTime || undefined,
        location: newItem.location || undefined
      }),
      ...(activeForm === 'note' && {
        content: newItem.content || undefined,
        tags: newItem.tags ? newItem.tags.split(',').map(t => t.trim()) : undefined
      })
    };

    setItems([...items, item]);
    setActiveForm(null);
    setNewItem({
      title: '',
      description: '',
      priority: 'medium',
      dueDate: '',
      startTime: '',
      endTime: '',
      location: '',
      content: '',
      tags: ''
    });
  };

  const handleDeleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const handleToggleTask = (id: string) => {
    setItems(items.map(item =>
      item.id === id && item.type === 'task'
        ? { ...item, completed: !item.completed }
        : item
    ));
  };

  const handleVoiceInput = () => {
    setIsListening(true);
    setTimeout(() => {
      setIsListening(false);
      // Simulate voice processing
      const commands = [
        "Schedule coffee with Sarah Tuesday 3pm",
        "Add task buy groceries by Friday",
        "Create note meeting ideas",
        "What do I have today?"
      ];
      const randomCommand = commands[Math.floor(Math.random() * commands.length)];
      setVoiceInput(randomCommand);

      // Process the command
      if (randomCommand.includes('Schedule')) {
        const newEvent: Item = {
          id: Date.now().toString(),
          type: 'calendar',
          title: 'Coffee with Sarah',
          startTime: '3:00 PM',
          endTime: '4:00 PM'
        };
        setItems([...items, newEvent]);
      } else if (randomCommand.includes('Add task')) {
        const newTask: Item = {
          id: Date.now().toString(),
          type: 'task',
          title: 'Buy groceries',
          dueDate: 'Friday',
          priority: 'medium',
          completed: false
        };
        setItems([...items, newTask]);
      } else if (randomCommand.includes('Create note')) {
        const newNote: Item = {
          id: Date.now().toString(),
          type: 'note',
          title: 'Meeting Ideas',
          content: 'Ideas for improving team meetings...'
        };
        setItems([...items, newNote]);
      }
    }, 2000);
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg-primary)',
      padding: '24px',
      position: 'relative'
    }}>
      {/* Header */}
      <div className="animate-fade-in" style={{
        background: 'var(--bg-card)',
        borderRadius: 'var(--radius-lg)',
        padding: '32px',
        marginBottom: '32px',
        boxShadow: 'var(--shadow-md)',
        border: '1px solid var(--border-primary)',
        backdropFilter: 'blur(20px)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1 style={{
              fontSize: '32px',
              fontWeight: '700',
              color: 'var(--text-primary)',
              margin: 0,
              background: 'var(--gradient-primary)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}>
              Personal Organizer
            </h1>
            <p style={{
              color: 'var(--text-secondary)',
              margin: '8px 0 0 0',
              fontSize: '16px',
              fontWeight: '500'
            }}>
              {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button
              onClick={() => setActiveForm('calendar')}
              style={{
                padding: '12px 20px',
                background: 'var(--gradient-blue)',
                color: 'white',
                border: 'none',
                borderRadius: 'var(--radius-md)',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                transition: 'all var(--transition-fast)',
                boxShadow: 'var(--shadow-sm)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = 'var(--shadow-md)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
              }}
            >
              <span style={{ fontSize: '16px' }}>📅</span>
              Calendar
            </button>
            <button
              onClick={() => setActiveForm('task')}
              style={{
                padding: '12px 20px',
                background: 'var(--gradient-green)',
                color: 'white',
                border: 'none',
                borderRadius: 'var(--radius-md)',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                transition: 'all var(--transition-fast)',
                boxShadow: 'var(--shadow-sm)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = 'var(--shadow-md)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
              }}
            >
              <span style={{ fontSize: '16px' }}>✅</span>
              Tasks
            </button>
            <button
              onClick={() => setActiveForm('note')}
              style={{
                padding: '12px 20px',
                background: 'var(--gradient-purple)',
                color: 'white',
                border: 'none',
                borderRadius: 'var(--radius-md)',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '600',
                transition: 'all var(--transition-fast)',
                boxShadow: 'var(--shadow-sm)',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = 'var(--shadow-md)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
              }}
            >
              <span style={{ fontSize: '16px' }}>📝</span>
              Notes
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '32px' }}>
        {/* Items List */}
        <div className="animate-slide-in" style={{
          background: 'var(--bg-card)',
          borderRadius: 'var(--radius-lg)',
          padding: '32px',
          boxShadow: 'var(--shadow-md)',
          border: '1px solid var(--border-primary)',
          backdropFilter: 'blur(20px)'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
            <h2 style={{
              fontSize: '24px',
              fontWeight: '700',
              color: 'var(--text-primary)',
              margin: 0
            }}>
              Your Items
            </h2>
            <div style={{
              background: 'var(--bg-tertiary)',
              padding: '8px 16px',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-secondary)',
              color: 'var(--text-secondary)',
              fontSize: '14px',
              fontWeight: '600'
            }}>
              {items.length} total
            </div>
          </div>

          {items.length === 0 ? (
            <div style={{
              textAlign: 'center',
              padding: '60px 20px',
              background: 'var(--bg-secondary)',
              borderRadius: 'var(--radius-md)',
              border: '2px dashed var(--border-accent)'
            }}>
              <div style={{ fontSize: '48px', marginBottom: '16px', opacity: 0.5 }}>📝</div>
              <p style={{
                color: 'var(--text-secondary)',
                fontSize: '18px',
                fontWeight: '500',
                marginBottom: '8px'
              }}>
                No items yet
              </p>
              <p style={{
                color: 'var(--text-tertiary)',
                fontSize: '14px'
              }}>
                Click the buttons above to create your first item!
              </p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {items.map((item, index) => (
                <div
                  key={item.id}
                  className="animate-fade-in"
                  style={{
                    animationDelay: `${index * 0.1}s`,
                    padding: '20px',
                    background: item.type === 'calendar'
                      ? 'linear-gradient(135deg, rgba(0, 122, 255, 0.1) 0%, rgba(0, 86, 204, 0.05) 100%)'
                      : item.type === 'task'
                      ? 'linear-gradient(135deg, rgba(48, 209, 88, 0.1) 0%, rgba(40, 167, 69, 0.05) 100%)'
                      : 'linear-gradient(135deg, rgba(175, 82, 222, 0.1) 0%, rgba(142, 68, 173, 0.05) 100%)',
                    borderRadius: 'var(--radius-md)',
                    border: `1px solid ${
                      item.type === 'calendar' ? 'rgba(0, 122, 255, 0.2)' :
                      item.type === 'task' ? 'rgba(48, 209, 88, 0.2)' : 'rgba(175, 82, 222, 0.2)'
                    }`,
                    borderLeft: `4px solid ${
                      item.type === 'calendar' ? 'var(--accent-blue)' :
                      item.type === 'task' ? 'var(--accent-green)' : 'var(--accent-purple)'
                    }`,
                    opacity: item.completed ? 0.6 : 1,
                    transition: 'all var(--transition-fast)',
                    cursor: 'pointer'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = 'var(--shadow-md)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1 }}>
                      {item.type === 'task' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleTask(item.id);
                          }}
                          style={{
                            background: item.completed ? 'var(--accent-green)' : 'var(--bg-tertiary)',
                            border: `2px solid ${item.completed ? 'var(--accent-green)' : 'var(--border-accent)'}`,
                            borderRadius: 'var(--radius-sm)',
                            width: '24px',
                            height: '24px',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            transition: 'all var(--transition-fast)',
                            color: item.completed ? 'white' : 'var(--text-tertiary)',
                            fontSize: '12px',
                            fontWeight: 'bold'
                          }}
                        >
                          {item.completed ? '✓' : ''}
                        </button>
                      )}
                      <div style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: 'var(--radius-sm)',
                        background: item.type === 'calendar'
                          ? 'var(--gradient-blue)'
                          : item.type === 'task'
                          ? 'var(--gradient-green)'
                          : 'var(--gradient-purple)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '18px'
                      }}>
                        {item.type === 'calendar' ? '📅' : item.type === 'task' ? '📋' : '📝'}
                      </div>
                      <div style={{ flex: 1 }}>
                        <h3 style={{
                          color: 'var(--text-primary)',
                          fontSize: '18px',
                          fontWeight: '600',
                          margin: 0,
                          textDecoration: item.completed ? 'line-through' : 'none'
                        }}>
                          {item.title}
                        </h3>
                        {item.description && (
                          <p style={{
                            color: 'var(--text-secondary)',
                            fontSize: '14px',
                            margin: '4px 0 0 0',
                            fontStyle: 'italic'
                          }}>
                            {item.description}
                          </p>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteItem(item.id);
                      }}
                      style={{
                        background: 'rgba(255, 69, 58, 0.1)',
                        border: '1px solid rgba(255, 69, 58, 0.2)',
                        borderRadius: 'var(--radius-sm)',
                        width: '32px',
                        height: '32px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'var(--accent-red)',
                        fontSize: '14px',
                        transition: 'all var(--transition-fast)'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.background = 'var(--accent-red)';
                        e.currentTarget.style.color = 'white';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.background = 'rgba(255, 69, 58, 0.1)';
                        e.currentTarget.style.color = 'var(--accent-red)';
                      }}
                    >
                      🗑️
                    </button>
                  </div>
                  <div style={{ marginTop: '12px' }}>
                    {item.type === 'calendar' && (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center' }}>
                        {item.startTime && (
                          <div style={{
                            background: 'var(--bg-tertiary)',
                            padding: '6px 12px',
                            borderRadius: 'var(--radius-sm)',
                            fontSize: '12px',
                            color: 'var(--text-secondary)',
                            fontWeight: '500'
                          }}>
                            🕐 {item.startTime} {item.endTime && `- ${item.endTime}`}
                          </div>
                        )}
                        {item.location && (
                          <div style={{
                            background: 'var(--bg-tertiary)',
                            padding: '6px 12px',
                            borderRadius: 'var(--radius-sm)',
                            fontSize: '12px',
                            color: 'var(--text-secondary)',
                            fontWeight: '500'
                          }}>
                            📍 {item.location}
                          </div>
                        )}
                      </div>
                    )}
                    {item.type === 'task' && (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center' }}>
                        {item.dueDate && (
                          <div style={{
                            background: 'var(--bg-tertiary)',
                            padding: '6px 12px',
                            borderRadius: 'var(--radius-sm)',
                            fontSize: '12px',
                            color: 'var(--text-secondary)',
                            fontWeight: '500'
                          }}>
                            📅 Due: {item.dueDate}
                          </div>
                        )}
                        {item.priority && (
                          <div style={{
                            background: item.priority === 'high'
                              ? 'rgba(255, 69, 58, 0.2)'
                              : item.priority === 'medium'
                              ? 'rgba(255, 159, 10, 0.2)'
                              : 'rgba(48, 209, 88, 0.2)',
                            color: item.priority === 'high'
                              ? 'var(--accent-red)'
                              : item.priority === 'medium'
                              ? 'var(--accent-orange)'
                              : 'var(--accent-green)',
                            padding: '6px 12px',
                            borderRadius: 'var(--radius-sm)',
                            fontSize: '12px',
                            fontWeight: '600'
                          }}>
                            {item.priority === 'high' ? '🔴' : item.priority === 'medium' ? '🟡' : '🟢'} {item.priority.charAt(0).toUpperCase() + item.priority.slice(1)}
                          </div>
                        )}
                      </div>
                    )}
                    {item.type === 'note' && (
                      <div>
                        {item.content && (
                          <p style={{
                            margin: '0 0 12px 0',
                            color: 'var(--text-secondary)',
                            fontSize: '14px',
                            lineHeight: '1.5'
                          }}>
                            {item.content}
                          </p>
                        )}
                        {item.tags && (
                          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                            {item.tags.map((tag, i) => (
                              <span key={i} style={{
                                background: 'var(--gradient-purple)',
                                color: 'white',
                                padding: '4px 12px',
                                borderRadius: 'var(--radius-md)',
                                fontSize: '12px',
                                fontWeight: '500'
                              }}>
                                #{tag}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Voice Interface */}
        <div className="animate-scale-in" style={{
          background: 'var(--bg-card)',
          borderRadius: 'var(--radius-lg)',
          padding: '32px',
          boxShadow: 'var(--shadow-md)',
          border: '1px solid var(--border-primary)',
          backdropFilter: 'blur(20px)',
          position: 'sticky',
          top: '24px'
        }}>
          <h2 style={{
            fontSize: '24px',
            fontWeight: '700',
            color: 'var(--text-primary)',
            marginBottom: '24px',
            textAlign: 'center'
          }}>
            Voice Assistant
          </h2>

          {voiceInput && (
            <div style={{
              padding: '20px',
              background: 'linear-gradient(135deg, rgba(0, 122, 255, 0.1) 0%, rgba(0, 86, 204, 0.05) 100%)',
              border: '1px solid rgba(0, 122, 255, 0.2)',
              borderRadius: 'var(--radius-md)',
              marginBottom: '24px',
              animation: 'fadeIn 0.5s ease-out'
            }}>
              <p style={{
                margin: '0 0 8px 0',
                fontWeight: '600',
                color: 'var(--accent-blue)',
                fontSize: '14px'
              }}>
                ✨ Voice Command Processed:
              </p>
              <p style={{
                margin: 0,
                color: 'var(--text-primary)',
                fontSize: '16px',
                fontStyle: 'italic'
              }}>
                "{voiceInput}"
              </p>
            </div>
          )}

          <div style={{ textAlign: 'center', marginBottom: '24px' }}>
            <button
              onClick={handleVoiceInput}
              disabled={isListening}
              className={isListening ? 'animate-pulse' : ''}
              style={{
                width: '100px',
                height: '100px',
                borderRadius: '50%',
                background: isListening
                  ? 'linear-gradient(135deg, #ff453a 0%, #e63946 100%)'
                  : 'var(--gradient-blue)',
                color: 'white',
                border: 'none',
                fontSize: '40px',
                cursor: isListening ? 'not-allowed' : 'pointer',
                boxShadow: isListening ? 'var(--shadow-xl)' : 'var(--shadow-lg)',
                transition: 'all var(--transition-normal)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
              onMouseEnter={(e) => {
                if (!isListening) {
                  e.currentTarget.style.transform = 'scale(1.05)';
                  e.currentTarget.style.boxShadow = 'var(--shadow-xl)';
                }
              }}
              onMouseLeave={(e) => {
                if (!isListening) {
                  e.currentTarget.style.transform = 'scale(1)';
                  e.currentTarget.style.boxShadow = 'var(--shadow-lg)';
                }
              }}
            >
              {isListening ? '🔴' : '🎤'}
            </button>
            <p style={{
              marginTop: '16px',
              color: isListening ? 'var(--accent-red)' : 'var(--text-secondary)',
              fontSize: '16px',
              fontWeight: '600'
            }}>
              {isListening ? 'Listening...' : 'Click to try voice input'}
            </p>
          </div>

          <div style={{
            background: 'var(--bg-secondary)',
            borderRadius: 'var(--radius-md)',
            padding: '20px',
            border: '1px solid var(--border-secondary)'
          }}>
            <p style={{
              fontWeight: '600',
              marginBottom: '12px',
              color: 'var(--text-primary)',
              fontSize: '14px'
            }}>
              💡 Try saying:
            </p>
            <ul style={{
              margin: 0,
              paddingLeft: '20px',
              color: 'var(--text-secondary)',
              fontSize: '14px',
              lineHeight: '1.6'
            }}>
              <li>"Schedule coffee with Sarah Tuesday 3pm"</li>
              <li>"Add task buy groceries by Friday"</li>
              <li>"Create note meeting ideas"</li>
              <li>"What do I have today?"</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Modal for Creating Items */}
      {activeForm && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0, 0, 0, 0.8)',
            backdropFilter: 'blur(10px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000,
            padding: '24px'
          }}
          onClick={() => setActiveForm(null)}
        >
          <div
            className="animate-scale-in"
            style={{
              background: 'var(--bg-card)',
              borderRadius: 'var(--radius-xl)',
              padding: '40px',
              maxWidth: '500px',
              width: '100%',
              maxHeight: '80vh',
              overflowY: 'auto',
              boxShadow: 'var(--shadow-xl)',
              border: '1px solid var(--border-primary)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px' }}>
              <div>
                <h2 style={{
                  fontSize: '28px',
                  fontWeight: '700',
                  color: 'var(--text-primary)',
                  margin: 0,
                  marginBottom: '8px'
                }}>
                  Create {activeForm.charAt(0).toUpperCase() + activeForm.slice(1)}
                </h2>
                <p style={{
                  color: 'var(--text-secondary)',
                  fontSize: '16px',
                  margin: 0
                }}>
                  {activeForm === 'calendar' && 'Schedule a new event or meeting'}
                  {activeForm === 'task' && 'Add a new task to your list'}
                  {activeForm === 'note' && 'Create a new note or idea'}
                </p>
              </div>
              <button
                onClick={() => setActiveForm(null)}
                style={{
                  background: 'var(--bg-tertiary)',
                  border: '1px solid var(--border-accent)',
                  borderRadius: '50%',
                  width: '40px',
                  height: '40px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--text-tertiary)',
                  fontSize: '18px',
                  transition: 'all var(--transition-fast)'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'var(--accent-red)';
                  e.currentTarget.style.color = 'white';
                  e.currentTarget.style.borderColor = 'var(--accent-red)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'var(--bg-tertiary)';
                  e.currentTarget.style.color = 'var(--text-tertiary)';
                  e.currentTarget.style.borderColor = 'var(--border-accent)';
                }}
              >
                ✕
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
              <div>
                <label style={{
                  display: 'block',
                  color: 'var(--text-primary)',
                  fontSize: '16px',
                  fontWeight: '600',
                  marginBottom: '8px'
                }}>
                  Title *
                </label>
                <input
                  type="text"
                  placeholder={`Enter ${activeForm} title...`}
                  value={newItem.title}
                  onChange={(e) => setNewItem({...newItem, title: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '16px',
                    background: 'var(--bg-secondary)',
                    border: '2px solid var(--border-primary)',
                    borderRadius: 'var(--radius-md)',
                    fontSize: '16px',
                    color: 'var(--text-primary)',
                    transition: 'all var(--transition-fast)'
                  }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = 'var(--accent-blue)';
                    e.currentTarget.style.boxShadow = '0 0 0 3px rgba(0, 122, 255, 0.1)';
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = 'var(--border-primary)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                />

              </div>

              {activeForm === 'calendar' && (
                <>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                    <div>
                      <label style={{
                        display: 'block',
                        color: 'var(--text-primary)',
                        fontSize: '14px',
                        fontWeight: '600',
                        marginBottom: '8px'
                      }}>
                        Start Time
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., 10:00 AM"
                        value={newItem.startTime}
                        onChange={(e) => setNewItem({...newItem, startTime: e.target.value})}
                        style={{
                          width: '100%',
                          padding: '16px',
                          background: 'var(--bg-secondary)',
                          border: '2px solid var(--border-primary)',
                          borderRadius: 'var(--radius-md)',
                          fontSize: '16px',
                          color: 'var(--text-primary)',
                          transition: 'all var(--transition-fast)'
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = 'var(--accent-blue)';
                          e.currentTarget.style.boxShadow = '0 0 0 3px rgba(0, 122, 255, 0.1)';
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = 'var(--border-primary)';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                    </div>
                    <div>
                      <label style={{
                        display: 'block',
                        color: 'var(--text-primary)',
                        fontSize: '14px',
                        fontWeight: '600',
                        marginBottom: '8px'
                      }}>
                        End Time
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., 11:00 AM"
                        value={newItem.endTime}
                        onChange={(e) => setNewItem({...newItem, endTime: e.target.value})}
                        style={{
                          width: '100%',
                          padding: '16px',
                          background: 'var(--bg-secondary)',
                          border: '2px solid var(--border-primary)',
                          borderRadius: 'var(--radius-md)',
                          fontSize: '16px',
                          color: 'var(--text-primary)',
                          transition: 'all var(--transition-fast)'
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = 'var(--accent-blue)';
                          e.currentTarget.style.boxShadow = '0 0 0 3px rgba(0, 122, 255, 0.1)';
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = 'var(--border-primary)';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <label style={{
                      display: 'block',
                      color: 'var(--text-primary)',
                      fontSize: '14px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                      Location
                    </label>
                    <input
                      type="text"
                      placeholder="e.g., Conference Room A"
                      value={newItem.location}
                      onChange={(e) => setNewItem({...newItem, location: e.target.value})}
                      style={{
                        width: '100%',
                        padding: '16px',
                        background: 'var(--bg-secondary)',
                        border: '2px solid var(--border-primary)',
                        borderRadius: 'var(--radius-md)',
                        fontSize: '16px',
                        color: 'var(--text-primary)',
                        transition: 'all var(--transition-fast)'
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = 'var(--accent-blue)';
                        e.currentTarget.style.boxShadow = '0 0 0 3px rgba(0, 122, 255, 0.1)';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = 'var(--border-primary)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    />
                  </div>
                </>
              )}

              {activeForm === 'task' && (
                <>
                  <div>
                    <label style={{
                      display: 'block',
                      color: 'var(--text-primary)',
                      fontSize: '14px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                      Due Date
                    </label>
                    <input
                      type="text"
                      placeholder="e.g., Tomorrow, Friday, Dec 25"
                      value={newItem.dueDate}
                      onChange={(e) => setNewItem({...newItem, dueDate: e.target.value})}
                      style={{
                        width: '100%',
                        padding: '16px',
                        background: 'var(--bg-secondary)',
                        border: '2px solid var(--border-primary)',
                        borderRadius: 'var(--radius-md)',
                        fontSize: '16px',
                        color: 'var(--text-primary)',
                        transition: 'all var(--transition-fast)'
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = 'var(--accent-green)';
                        e.currentTarget.style.boxShadow = '0 0 0 3px rgba(48, 209, 88, 0.1)';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = 'var(--border-primary)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    />
                  </div>
                  <div>
                    <label style={{
                      display: 'block',
                      color: 'var(--text-primary)',
                      fontSize: '14px',
                      fontWeight: '600',
                      marginBottom: '12px'
                    }}>
                      Priority Level
                    </label>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
                      {(['low', 'medium', 'high'] as const).map((priority) => (
                        <button
                          key={priority}
                          type="button"
                          onClick={() => setNewItem({...newItem, priority})}
                          style={{
                            padding: '16px',
                            background: newItem.priority === priority
                              ? (priority === 'high' ? 'var(--gradient-red)' : priority === 'medium' ? 'linear-gradient(135deg, #ff9f0a 0%, #e6900a 100%)' : 'var(--gradient-green)')
                              : 'var(--bg-secondary)',
                            color: newItem.priority === priority ? 'white' : 'var(--text-secondary)',
                            border: `2px solid ${newItem.priority === priority
                              ? (priority === 'high' ? 'var(--accent-red)' : priority === 'medium' ? 'var(--accent-orange)' : 'var(--accent-green)')
                              : 'var(--border-primary)'}`,
                            borderRadius: 'var(--radius-md)',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: '600',
                            transition: 'all var(--transition-fast)',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            gap: '8px'
                          }}
                        >
                          <span style={{ fontSize: '20px' }}>
                            {priority === 'high' ? '🔴' : priority === 'medium' ? '🟡' : '🟢'}
                          </span>
                          {priority.charAt(0).toUpperCase() + priority.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {activeForm === 'note' && (
                <>
                  <div>
                    <label style={{
                      display: 'block',
                      color: 'var(--text-primary)',
                      fontSize: '14px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                      Content
                    </label>
                    <textarea
                      placeholder="Write your note content here..."
                      value={newItem.content}
                      onChange={(e) => setNewItem({...newItem, content: e.target.value})}
                      style={{
                        width: '100%',
                        padding: '16px',
                        background: 'var(--bg-secondary)',
                        border: '2px solid var(--border-primary)',
                        borderRadius: 'var(--radius-md)',
                        fontSize: '16px',
                        color: 'var(--text-primary)',
                        transition: 'all var(--transition-fast)',
                        minHeight: '120px',
                        resize: 'vertical',
                        fontFamily: 'inherit'
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = 'var(--accent-purple)';
                        e.currentTarget.style.boxShadow = '0 0 0 3px rgba(175, 82, 222, 0.1)';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = 'var(--border-primary)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    />
                  </div>
                  <div>
                    <label style={{
                      display: 'block',
                      color: 'var(--text-primary)',
                      fontSize: '14px',
                      fontWeight: '600',
                      marginBottom: '8px'
                    }}>
                      Tags
                    </label>
                    <input
                      type="text"
                      placeholder="e.g., work, planning, ideas"
                      value={newItem.tags}
                      onChange={(e) => setNewItem({...newItem, tags: e.target.value})}
                      style={{
                        width: '100%',
                        padding: '16px',
                        background: 'var(--bg-secondary)',
                        border: '2px solid var(--border-primary)',
                        borderRadius: 'var(--radius-md)',
                        fontSize: '16px',
                        color: 'var(--text-primary)',
                        transition: 'all var(--transition-fast)'
                      }}
                      onFocus={(e) => {
                        e.currentTarget.style.borderColor = 'var(--accent-purple)';
                        e.currentTarget.style.boxShadow = '0 0 0 3px rgba(175, 82, 222, 0.1)';
                      }}
                      onBlur={(e) => {
                        e.currentTarget.style.borderColor = 'var(--border-primary)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    />
                  </div>
                </>
              )}

              <div>
                <label style={{
                  display: 'block',
                  color: 'var(--text-primary)',
                  fontSize: '14px',
                  fontWeight: '600',
                  marginBottom: '8px'
                }}>
                  Description (Optional)
                </label>
                <textarea
                  placeholder="Add additional details..."
                  value={newItem.description}
                  onChange={(e) => setNewItem({...newItem, description: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '16px',
                    background: 'var(--bg-secondary)',
                    border: '2px solid var(--border-primary)',
                    borderRadius: 'var(--radius-md)',
                    fontSize: '16px',
                    color: 'var(--text-primary)',
                    transition: 'all var(--transition-fast)',
                    minHeight: '80px',
                    resize: 'vertical',
                    fontFamily: 'inherit'
                  }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = 'var(--accent-blue)';
                    e.currentTarget.style.boxShadow = '0 0 0 3px rgba(0, 122, 255, 0.1)';
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = 'var(--border-primary)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                />
              </div>

              <div style={{ display: 'flex', gap: '16px', paddingTop: '8px' }}>
                <button
                  onClick={() => setActiveForm(null)}
                  style={{
                    flex: 1,
                    padding: '16px',
                    background: 'var(--bg-tertiary)',
                    color: 'var(--text-secondary)',
                    border: '2px solid var(--border-accent)',
                    borderRadius: 'var(--radius-md)',
                    fontSize: '16px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'all var(--transition-fast)'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'var(--border-accent)';
                    e.currentTarget.style.color = 'var(--text-primary)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'var(--bg-tertiary)';
                    e.currentTarget.style.color = 'var(--text-secondary)';
                  }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateItem}
                  disabled={!newItem.title.trim()}
                  style={{
                    flex: 2,
                    padding: '16px',
                    background: newItem.title.trim()
                      ? (activeForm === 'calendar' ? 'var(--gradient-blue)' : activeForm === 'task' ? 'var(--gradient-green)' : 'var(--gradient-purple)')
                      : 'var(--bg-tertiary)',
                    color: newItem.title.trim() ? 'white' : 'var(--text-muted)',
                    border: 'none',
                    borderRadius: 'var(--radius-md)',
                    fontSize: '16px',
                    fontWeight: '700',
                    cursor: newItem.title.trim() ? 'pointer' : 'not-allowed',
                    transition: 'all var(--transition-fast)',
                    boxShadow: newItem.title.trim() ? 'var(--shadow-md)' : 'none'
                  }}
                  onMouseEnter={(e) => {
                    if (newItem.title.trim()) {
                      e.currentTarget.style.transform = 'translateY(-2px)';
                      e.currentTarget.style.boxShadow = 'var(--shadow-lg)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (newItem.title.trim()) {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = 'var(--shadow-md)';
                    }
                  }}
                >
                  Create {activeForm?.charAt(0).toUpperCase() + activeForm?.slice(1)}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}


      {/* Quick Stats */}
      <div className="animate-fade-in" style={{
        background: 'var(--bg-card)',
        borderRadius: 'var(--radius-lg)',
        padding: '32px',
        marginTop: '32px',
        boxShadow: 'var(--shadow-md)',
        border: '1px solid var(--border-primary)',
        backdropFilter: 'blur(20px)'
      }}>
        <h2 style={{
          fontSize: '24px',
          fontWeight: '700',
          color: 'var(--text-primary)',
          marginBottom: '24px',
          textAlign: 'center'
        }}>
          Quick Stats
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px' }}>
          <div style={{
            textAlign: 'center',
            padding: '24px',
            background: 'linear-gradient(135deg, rgba(0, 122, 255, 0.1) 0%, rgba(0, 86, 204, 0.05) 100%)',
            borderRadius: 'var(--radius-md)',
            border: '1px solid rgba(0, 122, 255, 0.2)'
          }}>
            <div style={{ fontSize: '36px', fontWeight: '800', color: 'var(--accent-blue)', marginBottom: '8px' }}>
              {items.filter(item => item.type === 'calendar').length}
            </div>
            <div style={{ fontSize: '16px', color: 'var(--text-secondary)', fontWeight: '600' }}>Calendar Events</div>
          </div>
          <div style={{
            textAlign: 'center',
            padding: '24px',
            background: 'linear-gradient(135deg, rgba(48, 209, 88, 0.1) 0%, rgba(40, 167, 69, 0.05) 100%)',
            borderRadius: 'var(--radius-md)',
            border: '1px solid rgba(48, 209, 88, 0.2)'
          }}>
            <div style={{ fontSize: '36px', fontWeight: '800', color: 'var(--accent-green)', marginBottom: '8px' }}>
              {items.filter(item => item.type === 'task' && !item.completed).length}
            </div>
            <div style={{ fontSize: '16px', color: 'var(--text-secondary)', fontWeight: '600' }}>Active Tasks</div>
          </div>
          <div style={{
            textAlign: 'center',
            padding: '24px',
            background: 'linear-gradient(135deg, rgba(175, 82, 222, 0.1) 0%, rgba(142, 68, 173, 0.05) 100%)',
            borderRadius: 'var(--radius-md)',
            border: '1px solid rgba(175, 82, 222, 0.2)'
          }}>
            <div style={{ fontSize: '36px', fontWeight: '800', color: 'var(--accent-purple)', marginBottom: '8px' }}>
              {items.filter(item => item.type === 'note').length}
            </div>
            <div style={{ fontSize: '16px', color: 'var(--text-secondary)', fontWeight: '600' }}>Notes</div>
          </div>
          <div style={{
            textAlign: 'center',
            padding: '24px',
            background: 'linear-gradient(135deg, rgba(48, 209, 88, 0.15) 0%, rgba(40, 167, 69, 0.08) 100%)',
            borderRadius: 'var(--radius-md)',
            border: '1px solid rgba(48, 209, 88, 0.3)'
          }}>
            <div style={{ fontSize: '36px', fontWeight: '800', color: 'var(--accent-green)', marginBottom: '8px' }}>
              {items.filter(item => item.type === 'task' && item.completed).length}
            </div>
            <div style={{ fontSize: '16px', color: 'var(--text-secondary)', fontWeight: '600' }}>Completed</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
