# Voice Productivity App - Setup Instructions

## 🎯 **What This Is**
A voice-first productivity organizer with AI-powered task, calendar, and note management. Features include:
- Voice commands for creating/editing/deleting items
- Real-time auto-refresh and smart search
- Dark theme with mobile-responsive design
- Comprehensive development roadmap for premium features

## 🚀 **Quick Setup (5 minutes)**

### **Prerequisites**
- Node.js 18+ installed
- A Supabase account (free)
- A Google AI Studio account (free)

### **Step 1: Install Dependencies**
```bash
npm install
```

### **Step 2: Set Up Environment Variables**
1. Copy `.env.example` to `.env`
2. Fill in your API keys:

```env
# Supabase Configuration
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# Google Gemini AI Configuration  
VITE_GEMINI_API_KEY=your_gemini_api_key
```

### **Step 3: Set Up Supabase Database**
1. Create a new Supabase project at https://supabase.com
2. Go to SQL Editor in your Supabase dashboard
3. Run the SQL script from `supabase-schema.sql`
4. Copy your project URL and anon key to `.env`

### **Step 4: Set Up Google Gemini AI**
1. Go to https://aistudio.google.com
2. Create a new API key
3. Copy the API key to `.env`

### **Step 5: Run the Application**
```bash
npm run dev
```

Visit `http://localhost:5173` and start using voice commands!

## 📋 **Development Roadmap**

This project includes a comprehensive development plan:

- **`upcoming_tasks.md`** - 85+ tasks for premium transformation
- **`mobile_first_uiux_spec.md`** - Detailed UI/UX specifications
- **`Nikhil's Actions.md`** - Current status and feature selections

## 🎤 **Voice Commands Examples**
- "Create a meeting with John tomorrow at 3pm"
- "Add a task to buy groceries with high priority"
- "Make a note about project ideas"
- "Delete my dinner appointment"
- "Edit the client meeting to 4pm"

## 🔧 **Tech Stack**
- **Frontend:** React + TypeScript + Vite + Tailwind CSS
- **Backend:** Supabase (PostgreSQL + Real-time)
- **AI:** Google Gemini for natural language processing
- **Voice:** Web Speech API with enhanced pause tolerance
- **PWA:** Service worker ready for mobile installation

## 📞 **Support**
If you need help setting this up, refer to the detailed documentation in the project files or check the GitHub repository for updates.

**Repository:** https://github.com/nikhilgiri301/voice-productivity-app

---

**🎯 Status:** Production-ready core functionality with comprehensive roadmap for premium features.
